#! /bin/sh

# Script to build midisheetmusic.mono.exe on a Linux system, using Mono.NET.
# You need to install the following dependencies on Ubuntu Linux:
# sudo apt-get install mono-gmcs
# sudo apt-get install libmono-winforms2.0-cil
# sudo apt-get install mono-xbuild
# sudo apt-get install alsa-utils
# sudo apt-get install timidity

xbuild UnitTestDLL.csproj

